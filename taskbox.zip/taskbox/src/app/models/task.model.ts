// src/app/models/task.model.ts

export interface Task {
  id: string;
  title: string;
  state: string;
}